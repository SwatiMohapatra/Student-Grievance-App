from django.contrib import admin

from .models import DBDetail, TableDetail

admin.site.register(DBDetail)
admin.site.register(TableDetail)
