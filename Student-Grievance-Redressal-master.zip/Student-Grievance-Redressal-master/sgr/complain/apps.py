from django.apps import AppConfig


class ComplainConfig(AppConfig):
    name = 'complain'
