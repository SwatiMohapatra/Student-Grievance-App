# Student-Grievance-Redressal
It is a webapp made with Django framework of python.
